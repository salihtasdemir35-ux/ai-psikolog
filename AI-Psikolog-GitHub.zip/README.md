# AI Psikolog — Yapay Zekâ Destekli Psikolojik Destek

AI Psikolog; sesli ve yazılı görüşme yapabilen, dudak senkronlu, göz kırpan, dinlerken başını sallayan ve konuşmanın duygusuna göre yüz ifadesi değiştiren bir yapay zekâ destek uygulamasıdır. **Gerçek ya da lisanslı bir psikolog değildir**; uygulama bunu ilk açılışta ve her görüşmede açıkça belirtir.

## İçindekiler
- 🎙️ **Psikoloğumla Görüş**: sesli (eller serbest veya bas-konuş) ve yazılı görüşme, altyazı, ses seviyesi, sözünü kesme, görüşme süresi
- 🧑‍⚕️ **Avatar**: yerleşik çizim avatar ya da senin seçtiğin portre fotoğrafından canlandırılan gerçekçi avatar
- 📔 Duygu Günlüğüm (ruh hâli ve stres grafiği) · 🌬️ Stres Yönetimi (3 nefes egzersizi, 5-4-3-2-1, kas gevşetme, günlük değerlendirme) · 🌙 Uyku ve Rahatlama (beden taraması, yağmur/dalga/uğultu sesleri, uyku rutini) · 🧭 Kendimi Tanıyorum (BDT düşünce kaydı, ACT değerler, sorular, düşünce tuzakları) · 🗂️ Geçmiş Görüşmelerim (özetler, hedefler, notlar, egzersizler)
- 🆘 Kriz yönetimi: riskli ifadeleri hem uygulama hem yapay zekâ algılar; ülkeye göre doğrulanmış acil ve destek hatları gösterilir
- 🌍 14 dil: Türkçe, İngilizce, Almanca, Fransızca, İspanyolca, Arapça (sağdan sola), Rusça, İtalyanca, Portekizce, Çince, Japonca, Korece, Romence, Felemenkçe
- 🔒 Veriler yalnızca cihazda; isteğe bağlı PIN ile AES-256 şifreleme; dışa aktarma ve tümünü silme
- 📴 İnternet yokken günlük, egzersizler ve uyku sesleri çalışır

---

## 1. Ücretsiz API anahtarı al (5 dakika)
Yapay zekâ “beyni” için en az bir anahtar gerekir. **İkisini birden almanı öneririm**:

| Sağlayıcı | Ne işe yarar | Nereden |
|---|---|---|
| **Google Gemini** | Ana yapay zekâ + doğal kadın sesi | https://aistudio.google.com/apikey |
| **Groq** | Yedek yapay zekâ + yüksek doğrulukta ses tanıma (Whisper) | https://console.groq.com/keys |
| OpenRouter (isteğe bağlı) | Ücretsiz modellerle ikinci yedek | https://openrouter.ai/keys |

Anahtarı uygulamada **Ayarlar → Yapay zekâ ve ses sağlayıcıları** bölümüne yapıştırıp **Test et**'e bas. Biri kotasını doldurursa uygulama otomatik olarak diğerine geçer. Ücretli planlar asla otomatik kullanılmaz.

## 2. Hemen dene (bilgisayarda, kurulum yok)
`www/index.html` dosyasını **Chrome** veya **Edge** ile aç. Mikrofon iznini ver. Hepsi bu.

## 3. Android APK yap (GitHub ile, zip'i açmadan)
1. github.com → sağ üst **+** → **New repository** → ad: `ai-psikolog` → **Public** → **Create repository**.
2. **uploading an existing file** → **AI-Psikolog-GitHub.zip** dosyasını açmadan sürükle → **Commit changes**.
3. **Add file** → **Create new file** → dosya adı: `.github/workflows/build-apk.yml` → `build-apk.yml` dosyasının içeriğini yapıştır → **Commit changes**.
4. **Actions** sekmesi → **APK Oluştur** → 6–10 dakika bekle → yeşil ✔.
5. Ana sayfa → sağda **Releases** → **AI-Psikolog.apk** dosyasını indir ve telefona kur.

Güncelleme: yeni zip'i **Add file → Upload files** ile yükle (eskisini silmene gerek yok; en yenisi kullanılır). APK otomatik yeniden derlenir.

## 4. Gerçekçi avatar (fotoğraf modu)
**Ayarlar → Avatar → Gerçekçi fotoğraf → Portre fotoğrafı seç.** Önden çekilmiş, iyi ışıklı, ağzı kapalı bir portre kullan (örneğin bir yapay zekâ görsel aracıyla ürettiğin, kullanım hakkı sende olan bir kadın psikolog portresi). Ardından fotoğrafta sırayla **sol göze, sağ göze ve ağzın ortasına** dokun → **Kaydet**. Avatar artık o yüzle konuşur: dudaklar sesle senkron açılır, gözler kırpılır, baş hafifçe hareket eder.

## 5. Ses ipuçları
- **En doğal ses:** Ayarlar → Seslendirme → *Gemini doğal ses* (Gemini anahtarı gerekir; 10 kadın sesi arasından seçilir). Kotası dolarsa otomatik olarak cihaz sesine geçer.
- **Cihaz sesi kalitesi telefona bağlıdır.** Android'de *Ayarlar → Erişilebilirlik → Metin okuma* bölümünden Google'ın dil paketini indirmek sesi belirgin biçimde iyileştirir.
- **iPhone / Safari'de** tarayıcı ses tanıma sınırlıdır; Groq anahtarı eklersen ses tanıma her cihazda çalışır.
- Psikolog konuşurken **avatara dokunarak** sözünü kesebilirsin. Kulaklıkla *Konuşarak sözünü kes* seçeneğini de açabilirsin.

## 6. Gizlilik ve güvenlik
- API anahtarları kodda **yoktur**; yalnızca cihazında saklanır. PIN belirlersen tüm veriler (anahtarlar dâhil) AES-256 ile şifrelenir.
- Ses kayıtları **hiçbir zaman** saklanmaz. Yanıt üretmek için yalnızca metin, seçtiğin sağlayıcıya gönderilir.
- Görüşmelerin tam metni değil, yalnızca kısa özeti saklanır (Hafıza kapatılırsa hiçbiri saklanmaz).
- Uygulama 18 yaş altı kullanıcıya yapay zekâ görüşmesini kapatır; günlük, egzersizler ve yardım hatları açık kalır.

## 7. Sorun giderme
| Sorun | Çözüm |
|---|---|
| Actions kırmızı ✗ | Actions → başarısız iş → **Re-run jobs**. Tekrar olursa hata satırını bana gönder. |
| “Bağlantı başarısız” | Anahtarı boşluksuz yapıştırdığını kontrol et; internet bağlantını kontrol et. |
| Mikrofon çalışmıyor | Telefon Ayarlar → Uygulamalar → AI Psikolog → İzinler → Mikrofon: İzin ver. |
| Sesli yanıt yok | Görüşmede 🔊 açık mı? Ses seviyesi kaydırıcısını kontrol et. |
| “Sağlayıcılar meşgul” | Ücretsiz kota dolmuş olabilir; birkaç dakika bekle ya da ikinci bir sağlayıcı anahtarı ekle. |

## Dosya yapısı
```
.github/workflows/build-apk.yml   → GitHub'da APK'yı otomatik derler
www/index.html                    → Uygulamanın tamamı (tek dosya)
resources/                        → Uygulama simgesi ve açılış ekranı
scripts/patch-android.js          → Mikrofon/bildirim izinlerini ekler
capacitor.config.json, package.json
```

> Bu uygulamadaki psikolog bir yapay zekâdır; tanı koymaz, ilaç önermez ve profesyonel desteğin yerini tutmaz. Acil bir durumda bulunduğun ülkenin acil numarasını ara (Türkiye: **112**).
