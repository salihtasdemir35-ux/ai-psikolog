// AndroidManifest'e mikrofon, bildirim izinleri ve ses servisleri için <queries> ekler.
const fs = require('fs');
const p = 'android/app/src/main/AndroidManifest.xml';
let m = fs.readFileSync(p, 'utf8');
const perms = ['android.permission.INTERNET', 'android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS', 'android.permission.POST_NOTIFICATIONS'];
for (const x of perms) if (!m.includes(x)) m = m.replace('</manifest>', `    <uses-permission android:name="${x}" />\n</manifest>`);
if (!m.includes('android.speech.RecognitionService')) {
  m = m.replace('</manifest>', `    <queries>
        <intent><action android:name="android.speech.RecognitionService" /></intent>
        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>
    </queries>
</manifest>`);
}
fs.writeFileSync(p, m);
console.log('AndroidManifest güncellendi');
